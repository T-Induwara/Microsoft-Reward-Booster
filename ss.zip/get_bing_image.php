<?php
$bingApiUrl = "https://www.bing.com/HPImageArchive.aspx?format=js&idx=0&n=1";
$response = file_get_contents($bingApiUrl);
echo $response;
?>
